import 'dart:async';

import 'package:dio/dio.dart';
import 'package:clearmarket/core/failures.dart';
import 'package:clearmarket/core/theme.dart';
import 'package:clearmarket/features/feed/article_card.dart';
import 'package:clearmarket/features/feed/article_model.dart';
import 'package:clearmarket/features/feed/feed_controller.dart';
import 'package:clearmarket/features/feed/feed_repository.dart';
import 'package:clearmarket/features/feed/feed_skeleton.dart';
import 'package:clearmarket/features/feed/feed_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:timeago/timeago.dart' as timeago;

Map<String, dynamic> articleJson(String id, {String? sentiment}) => {
  'id': id,
  'title': 'Titolo $id',
  'summary': 'Sommario',
  'source': {'slug': 'ecb', 'name': 'BCE'},
  'source_url': 'https://example.com/$id',
  'translated': true,
  'published_at': '2026-11-05T09:00:00+00:00',
  'category': 'macro',
  'related_tickers': ['AAPL', 'BTC'],
  'sentiment': {'label': sentiment ?? 'negative', 'score': -0.4},
};

ArticleModel article(String id) => ArticleModel.fromJson(articleJson(id));

FeedPage page(List<String> ids, [String? next]) =>
    FeedPage(items: ids.map(article).toList(), nextCursor: next);

/// Risposte accodate; un Completer permette di tenere una richiesta "in volo".
class FakeRepository implements FeedRepository {
  final responses = <Object>[];
  final cursors = <String?>[];

  @override
  Future<FeedPage> fetch(FeedKind kind, {String? cursor}) async {
    cursors.add(cursor);
    final next = responses.removeAt(0);
    return switch (next) {
      final Completer<FeedPage> completer => completer.future,
      final FeedPage page => page,
      final Object error => throw error,
    };
  }
}

ProviderContainer containerWith(FeedRepository repository) {
  final container = ProviderContainer(
    overrides: [feedRepositoryProvider.overrideWithValue(repository)],
    retry: (_, _) => null,
  );
  addTearDown(container.dispose);
  return container;
}

void main() {
  setUpAll(() => timeago.setLocaleMessages('it', timeago.ItMessages()));

  group('ArticleModel.fromJson', () {
    test('mappa tutti i campi e converte la data in locale', () {
      final model = article('1');
      expect(model.sourceName, 'BCE');
      expect(model.sourceUrl, 'https://example.com/1');
      expect(model.translated, isTrue);
      expect(model.relatedTickers, ['AAPL', 'BTC']);
      expect(model.sentiment, Sentiment.negative);
      expect(model.publishedAt.isUtc, isFalse);
      expect(
        model.publishedAt.toUtc(),
        DateTime.utc(2026, 11, 5, 9),
      );
    });

    test('tollera sentiment sconosciuto e campi opzionali assenti', () {
      final json = articleJson('1', sentiment: 'mixed')
        ..remove('summary')
        ..remove('related_tickers');
      final model = ArticleModel.fromJson(json);
      expect(model.sentiment, Sentiment.neutral);
      expect(model.summary, isEmpty);
      expect(model.relatedTickers, isEmpty);
    });

    test('il payload senza pagina successiva azzera il cursore', () {
      final parsed = FeedPage.fromJson({
        'data': [articleJson('1')],
        'page_info': {'next_cursor': null, 'has_more': false, 'limit': 20},
      });
      expect(parsed.nextCursor, isNull);
      expect(parsed.items, hasLength(1));
    });
  });

  group('mapDioError', () {
    DioException withStatus(int? status) {
      final options = RequestOptions(path: '/x');
      return DioException(
        requestOptions: options,
        response: status == null
            ? null
            : Response(requestOptions: options, statusCode: status),
      );
    }

    test('traduce gli stati HTTP', () {
      expect(mapDioError(withStatus(429)), isA<RateLimitFailure>());
      expect(mapDioError(withStatus(401)), isA<AuthFailure>());
      expect(mapDioError(withStatus(500)), isA<ServerFailure>());
      expect(mapDioError(withStatus(null)), isA<NetworkFailure>());
    });
  });

  group('FeedController', () {
    final provider = feedControllerProvider(FeedKind.top);

    test('accoda le pagine usando il cursore', () async {
      final repository = FakeRepository()
        ..responses.addAll([page(['1', '2'], 'c1'), page(['3'])]);
      final container = containerWith(repository);
      await container.read(provider.future);

      await container.read(provider.notifier).loadMore();

      final state = container.read(provider).value!;
      expect(state.items.map((a) => a.id), ['1', '2', '3']);
      expect(state.hasMore, isFalse);
      expect(repository.cursors, [null, 'c1']);
    });

    test('non parte una seconda pagina mentre una e\' in volo', () async {
      final inFlight = Completer<FeedPage>();
      final repository = FakeRepository()
        ..responses.addAll([page(['1'], 'c1'), inFlight]);
      final container = containerWith(repository);
      await container.read(provider.future);

      final first = container.read(provider.notifier).loadMore();
      await container.read(provider.notifier).loadMore();
      inFlight.complete(page(['2']));
      await first;

      expect(repository.cursors, [null, 'c1']);
    });

    test('un errore di pagina conserva la lista e non ritenta da solo', () async {
      final repository = FakeRepository()
        ..responses.addAll([
          page(['1'], 'c1'),
          const NetworkFailure(),
          page(['2']),
        ]);
      final container = containerWith(repository);
      await container.read(provider.future);
      final controller = container.read(provider.notifier);

      await controller.loadMore();
      expect(container.read(provider).value!.loadMoreError, isNotNull);
      expect(container.read(provider).value!.items, hasLength(1));

      await controller.loadMore();
      expect(repository.cursors, hasLength(2));

      await controller.retryLoadMore();
      final state = container.read(provider).value!;
      expect(state.loadMoreError, isNull);
      expect(state.items.map((a) => a.id), ['1', '2']);
    });

    test('refresh fallito lascia i dati e propaga l\'errore', () async {
      final repository = FakeRepository()
        ..responses.addAll([page(['1']), const NetworkFailure()]);
      final container = containerWith(repository);
      await container.read(provider.future);

      await expectLater(
        container.read(provider.notifier).refresh(),
        throwsA(isA<NetworkFailure>()),
      );
      expect(container.read(provider).value!.items, hasLength(1));
    });

    test('una pagina arrivata dopo un refresh viene scartata', () async {
      final slowPage = Completer<FeedPage>();
      final repository = FakeRepository()
        ..responses.addAll([page(['1'], 'c1'), slowPage, page(['9'])]);
      final container = containerWith(repository);
      await container.read(provider.future);
      final controller = container.read(provider.notifier);

      final pending = controller.loadMore();
      await controller.refresh();
      slowPage.complete(page(['2']));
      await pending;

      final state = container.read(provider).value!;
      expect(state.items.map((a) => a.id), ['9']);
      expect(state.isLoadingMore, isFalse);
    });

    test('righe gia\' presenti non vengono duplicate', () async {
      final repository = FakeRepository()
        ..responses.addAll([page(['1', '2'], 'c1'), page(['2', '3'])]);
      final container = containerWith(repository);
      await container.read(provider.future);
      await container.read(provider.notifier).loadMore();
      expect(
        container.read(provider).value!.items.map((a) => a.id),
        ['1', '2', '3'],
      );
    });
  });

  group('UI', () {
    Widget harness(FeedRepository repository, Widget child) => ProviderScope(
      overrides: [feedRepositoryProvider.overrideWithValue(repository)],
      retry: (_, _) => null,
      child: MaterialApp(
        theme: darkTheme,
        home: Scaffold(body: child),
      ),
    );

    testWidgets('la card mostra fonte, titolo, ticker e sentiment', (
      tester,
    ) async {
      ArticleModel? opened;
      await tester.pumpWidget(
        harness(
          FakeRepository(),
          ArticleCard(article: article('1'), onOpen: (a) => opened = a),
        ),
      );
      expect(find.text('BCE'), findsOneWidget);
      expect(find.text('Titolo 1'), findsOneWidget);
      expect(find.text('AAPL'), findsOneWidget);
      expect(find.text('Negativo'), findsOneWidget);
      expect(find.textContaining('Tradotto'), findsOneWidget);

      await tester.tap(find.text('Titolo 1'));
      expect(opened?.id, '1');
    });

    testWidgets('il sentiment neutro non occupa spazio', (tester) async {
      await tester.pumpWidget(
        harness(
          FakeRepository(),
          ArticleCard(
            article: ArticleModel.fromJson(articleJson('1', sentiment: 'neutral')),
          ),
        ),
      );
      expect(find.byType(SentimentChip), findsNothing);
    });

    testWidgets('skeleton poi dati', (tester) async {
      final pending = Completer<FeedPage>();
      final repository = FakeRepository()..responses.add(pending);
      await tester.pumpWidget(
        harness(repository, const FeedView(kind: FeedKind.top)),
      );
      expect(find.byType(FeedSkeleton), findsOneWidget);

      pending.complete(page(['1']));
      await tester.pump();
      await tester.pump();
      expect(find.byType(FeedSkeleton), findsNothing);
      expect(find.text('Titolo 1'), findsOneWidget);
      expect(find.text('Sei aggiornato'), findsOneWidget);
    });

    testWidgets('errore a pagina piena con Riprova funzionante', (tester) async {
      final repository = FakeRepository()
        ..responses.addAll([const NetworkFailure(), page(['1'])]);
      await tester.pumpWidget(
        harness(repository, const FeedView(kind: FeedKind.top)),
      );
      await tester.pumpAndSettle();
      expect(find.text(const NetworkFailure().message), findsOneWidget);

      await tester.tap(find.text('Riprova'));
      await tester.pumpAndSettle();
      expect(find.text('Titolo 1'), findsOneWidget);
    });

    testWidgets('lo scroll verso il fondo carica la pagina successiva', (
      tester,
    ) async {
      final repository = FakeRepository()
        ..responses.addAll([
          page(List.generate(20, (i) => '$i'), 'c1'),
          page(['fine']),
        ]);
      await tester.pumpWidget(
        harness(repository, const FeedView(kind: FeedKind.top)),
      );
      await tester.pumpAndSettle();

      await tester.drag(find.byType(ListView), const Offset(0, -3000));
      await tester.pumpAndSettle();
      expect(repository.cursors, contains('c1'));
    });

    testWidgets('lista vuota mostra lo stato dedicato', (tester) async {
      final repository = FakeRepository()..responses.add(page([]));
      await tester.pumpWidget(
        harness(
          repository,
          const FeedView(kind: FeedKind.watchlist, emptyState: Text('Vuota')),
        ),
      );
      await tester.pumpAndSettle();
      expect(find.text('Vuota'), findsOneWidget);
    });
  });
}
