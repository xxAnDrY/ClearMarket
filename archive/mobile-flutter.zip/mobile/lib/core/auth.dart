import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'config.dart';

/// Fonte del token Bearer per le rotte personali (watchlist).
abstract interface class TokenSource {
  Future<String?> accessToken();
}

/// Autenticazione anonima: l'utente ha una watchlist da subito, senza registrarsi.
/// In seguito puo' collegare un'email allo stesso `user_id`.
final class SupabaseTokenSource implements TokenSource {
  @override
  Future<String?> accessToken() async {
    final auth = Supabase.instance.client.auth;
    var session = auth.currentSession;
    if (session == null) {
      session = (await auth.signInAnonymously()).session;
    } else if (session.isExpired) {
      session = (await auth.refreshSession()).session;
    }
    return session?.accessToken;
  }
}

final class StaticTokenSource implements TokenSource {
  const StaticTokenSource(this.token);
  final String token;

  @override
  Future<String?> accessToken() async => token.isEmpty ? null : token;
}

final tokenSourceProvider = Provider<TokenSource>((ref) {
  return AppConfig.hasSupabase
      ? SupabaseTokenSource()
      : const StaticTokenSource(AppConfig.devJwt);
});
