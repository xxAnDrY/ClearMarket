/// Configurazione di build, passata con `--dart-define`.
abstract final class AppConfig {
  /// Nessun default: ogni dispositivo raggiunge il backend a un indirizzo diverso
  /// (telefono: IP del PC o dominio; emulatore Android: 10.0.2.2).
  static const apiBaseUrl = String.fromEnvironment('API_BASE_URL');

  static const supabaseUrl = String.fromEnvironment('SUPABASE_URL');
  static const supabasePublishableKey = String.fromEnvironment('SUPABASE_PUBLISHABLE_KEY');

  /// Solo sviluppo locale senza Supabase: vedi `backend/scripts/mint_dev_token.py`.
  static const devJwt = String.fromEnvironment('DEV_JWT');

  static bool get hasSupabase =>
      supabaseUrl.isNotEmpty && supabasePublishableKey.isNotEmpty;
}
