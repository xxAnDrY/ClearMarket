import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'auth.dart';
import 'config.dart';
import 'failures.dart';

/// Allega il token solo alle rotte personali: le pubbliche restano cacheabili
/// e funzionano anche se l'autenticazione non e' disponibile.
class _AuthInterceptor extends Interceptor {
  _AuthInterceptor(this._tokens);
  final TokenSource _tokens;

  static bool _isPrivate(String path) =>
      path.contains('/me/') || path.endsWith('/feed/watchlist');

  @override
  Future<void> onRequest(
    RequestOptions options,
    RequestInterceptorHandler handler,
  ) async {
    if (!_isPrivate(options.path)) return handler.next(options);
    try {
      final token = await _tokens.accessToken();
      if (token == null) {
        return handler.reject(
          DioException(requestOptions: options, error: const AuthFailure()),
        );
      }
      options.headers['Authorization'] = 'Bearer $token';
      handler.next(options);
    } catch (_) {
      handler.reject(
        DioException(requestOptions: options, error: const NetworkFailure()),
      );
    }
  }
}

final dioProvider = Provider<Dio>((ref) {
  final dio = Dio(
    BaseOptions(
      baseUrl: AppConfig.apiBaseUrl,
      connectTimeout: const Duration(seconds: 8),
      receiveTimeout: const Duration(seconds: 10),
    ),
  );
  dio.interceptors.add(_AuthInterceptor(ref.watch(tokenSourceProvider)));
  ref.onDispose(dio.close);
  return dio;
});
