import 'package:flutter/material.dart';

/// Colori semantici non coperti da `ColorScheme`.
@immutable
class MarketColors extends ThemeExtension<MarketColors> {
  const MarketColors({
    required this.positive,
    required this.negative,
    required this.neutral,
  });

  final Color positive;
  final Color negative;
  final Color neutral;

  static const dark = MarketColors(
    positive: Color(0xFF3DD68C),
    negative: Color(0xFFFF6B6B),
    neutral: Color(0xFF9AA4B2),
  );
  static const light = MarketColors(
    positive: Color(0xFF0B7A4B),
    negative: Color(0xFFC62828),
    neutral: Color(0xFF5B6573),
  );

  @override
  MarketColors copyWith({Color? positive, Color? negative, Color? neutral}) =>
      MarketColors(
        positive: positive ?? this.positive,
        negative: negative ?? this.negative,
        neutral: neutral ?? this.neutral,
      );

  @override
  MarketColors lerp(MarketColors? other, double t) {
    if (other == null) return this;
    return MarketColors(
      positive: Color.lerp(positive, other.positive, t)!,
      negative: Color.lerp(negative, other.negative, t)!,
      neutral: Color.lerp(neutral, other.neutral, t)!,
    );
  }
}

const _accent = Color(0xFFFFB000); // ambra da terminale finanziario

ThemeData _build(Brightness brightness) {
  final isDark = brightness == Brightness.dark;
  final scheme = ColorScheme.fromSeed(
    seedColor: _accent,
    brightness: brightness,
    surface: isDark ? const Color(0xFF0B0E11) : const Color(0xFFFAFAF7),
    primary: isDark ? _accent : const Color(0xFF8A5F00),
  );
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: scheme.surface,
    dividerColor: scheme.outlineVariant.withValues(alpha: 0.4),
    appBarTheme: AppBarTheme(
      backgroundColor: scheme.surface,
      surfaceTintColor: Colors.transparent,
      titleTextStyle: TextStyle(
        color: scheme.onSurface,
        fontSize: 20,
        fontWeight: FontWeight.w800,
        letterSpacing: -0.3,
      ),
    ),
    textTheme: const TextTheme(
      titleMedium: TextStyle(
        fontSize: 17,
        height: 1.28,
        fontWeight: FontWeight.w700,
        letterSpacing: -0.2,
      ),
      bodyMedium: TextStyle(fontSize: 14, height: 1.4),
      labelSmall: TextStyle(fontSize: 12, letterSpacing: 0.1),
    ),
    extensions: [isDark ? MarketColors.dark : MarketColors.light],
  );
}

final lightTheme = _build(Brightness.light);
final darkTheme = _build(Brightness.dark);
