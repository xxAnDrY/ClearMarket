import 'package:dio/dio.dart';

/// Errori di dominio: la UI mostra `message`, non i dettagli del trasporto.
sealed class AppFailure implements Exception {
  const AppFailure(this.message);
  final String message;

  @override
  String toString() => message;
}

final class NetworkFailure extends AppFailure {
  const NetworkFailure() : super('Connessione assente o lenta. Riprova.');
}

final class RateLimitFailure extends AppFailure {
  const RateLimitFailure() : super('Troppe richieste. Riprova tra un minuto.');
}

final class AuthFailure extends AppFailure {
  const AuthFailure() : super('Sessione non valida. Riapri l\'app.');
}

final class ServerFailure extends AppFailure {
  const ServerFailure() : super('Il servizio non risponde. Riprova tra poco.');
}

AppFailure mapDioError(DioException error) {
  if (error.error is AppFailure) return error.error! as AppFailure;
  return switch (error.response?.statusCode) {
    429 => const RateLimitFailure(),
    401 || 403 => const AuthFailure(),
    int() => const ServerFailure(),
    null => const NetworkFailure(),
  };
}
