import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:timeago/timeago.dart' as timeago;

import 'app.dart';
import 'core/config.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (AppConfig.apiBaseUrl.isEmpty) {
    runApp(const _MissingConfigApp());
    return;
  }
  timeago.setLocaleMessages('it', timeago.ItMessages());
  await initializeDateFormatting('it');
  if (AppConfig.hasSupabase) {
    await Supabase.initialize(
      url: AppConfig.supabaseUrl,
      publishableKey: AppConfig.supabasePublishableKey,
    );
  }
  runApp(
    // Niente retry automatico: gli stati di errore hanno un pulsante "Riprova".
    ProviderScope(retry: (_, _) => null, child: const ClearMarketApp()),
  );
}

/// Una build senza indirizzo fallirebbe con errori di rete generici.
class _MissingConfigApp extends StatelessWidget {
  const _MissingConfigApp();

  @override
  Widget build(BuildContext context) => const MaterialApp(
    home: Scaffold(
      body: Center(
        child: Padding(
          padding: EdgeInsets.all(32),
          child: Text(
            'API_BASE_URL mancante. Ricompila con '
            '--dart-define-from-file=config/dev.json',
            textAlign: TextAlign.center,
          ),
        ),
      ),
    ),
  );
}
