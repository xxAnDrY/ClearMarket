import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/failures.dart';
import '../feed/feed_repository.dart';
import '../feed/feed_view.dart';
import 'watchlist_controller.dart';

class WatchlistScreen extends StatelessWidget {
  const WatchlistScreen({super.key});

  void _edit(BuildContext context) => showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (_) => const _WatchlistEditor(),
  );

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('Watchlist'),
      actions: [
        IconButton(
          tooltip: 'Modifica watchlist',
          icon: const Icon(Icons.tune),
          onPressed: () => _edit(context),
        ),
      ],
    ),
    body: FeedView(
      kind: FeedKind.watchlist,
      emptyState: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Segui ticker e categorie per costruire il tuo feed.',
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: () => _edit(context),
              child: const Text('Aggiungi'),
            ),
          ],
        ),
      ),
    ),
  );
}

class _WatchlistEditor extends ConsumerStatefulWidget {
  const _WatchlistEditor();

  @override
  ConsumerState<_WatchlistEditor> createState() => _WatchlistEditorState();
}

class _WatchlistEditorState extends ConsumerState<_WatchlistEditor> {
  final _ticker = TextEditingController();

  @override
  void dispose() {
    _ticker.dispose();
    super.dispose();
  }

  Future<void> _guard(Future<void> Function() action) async {
    final messenger = ScaffoldMessenger.of(context);
    try {
      await action();
    } on AppFailure catch (failure) {
      messenger.showSnackBar(SnackBar(content: Text(failure.message)));
    }
  }

  Future<void> _addTicker() async {
    final value = _ticker.text;
    _ticker.clear();
    await _guard(
      () => ref.read(watchlistProvider.notifier).addTicker(value),
    );
  }

  @override
  Widget build(BuildContext context) {
    final watchlist = ref.watch(watchlistProvider);
    final categories = ref.watch(categoriesProvider);
    final notifier = ref.read(watchlistProvider.notifier);
    final current = watchlist.value;

    return Padding(
      padding: EdgeInsets.fromLTRB(
        16,
        0,
        16,
        16 + MediaQuery.viewInsetsOf(context).bottom,
      ),
      child: switch (current) {
        null when watchlist.hasError => ErrorRetry(
          message: watchlist.error is AppFailure
              ? (watchlist.error! as AppFailure).message
              : const ServerFailure().message,
          onRetry: () => ref.invalidate(watchlistProvider),
        ),
        null => const SizedBox(
          height: 160,
          child: Center(child: CircularProgressIndicator()),
        ),
        final Watchlist list => Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _ticker,
              textCapitalization: TextCapitalization.characters,
              textInputAction: TextInputAction.done,
              onSubmitted: (_) => _addTicker(),
              decoration: InputDecoration(
                labelText: 'Aggiungi ticker (es. AAPL, BTC, UCG.MI)',
                suffixIcon: IconButton(
                  tooltip: 'Aggiungi',
                  icon: const Icon(Icons.add),
                  onPressed: _addTicker,
                ),
              ),
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              children: [
                for (final ticker in list.tickers)
                  InputChip(
                    label: Text(ticker),
                    onDeleted: () =>
                        _guard(() => notifier.removeTicker(ticker)),
                  ),
              ],
            ),
            const SizedBox(height: 16),
            Text('Categorie', style: Theme.of(context).textTheme.titleSmall),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: [
                for (final category in categories.value ?? const <Category>[])
                  FilterChip(
                    label: Text(category.label),
                    selected: list.categories.contains(category.slug),
                    onSelected: (_) =>
                        _guard(() => notifier.toggleCategory(category.slug)),
                  ),
              ],
            ),
          ],
        ),
      },
    );
  }
}
