import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/api_client.dart';
import '../../core/failures.dart';
import '../feed/feed_controller.dart';
import '../feed/feed_repository.dart';

@immutable
class Watchlist {
  const Watchlist({this.tickers = const [], this.categories = const []});

  factory Watchlist.fromJson(Map<String, dynamic> json) => Watchlist(
    tickers: List<String>.unmodifiable(json['tickers'] as List<dynamic>),
    categories: List<String>.unmodifiable(json['categories'] as List<dynamic>),
  );

  final List<String> tickers;
  final List<String> categories;

  Map<String, dynamic> toJson() => {
    'tickers': tickers,
    'categories': categories,
  };
}

@immutable
class Category {
  const Category(this.slug, this.label);
  final String slug;
  final String label;
}

abstract interface class WatchlistRepository {
  Future<Watchlist> load();
  Future<Watchlist> save(Watchlist watchlist);
  Future<List<Category>> categories();
}

class ApiWatchlistRepository implements WatchlistRepository {
  const ApiWatchlistRepository(this._dio);
  final Dio _dio;

  @override
  Future<Watchlist> load() async {
    try {
      final response = await _dio.get<Map<String, dynamic>>(
        '/api/v1/me/watchlist',
      );
      return Watchlist.fromJson(response.data!);
    } on DioException catch (error) {
      throw mapDioError(error);
    }
  }

  @override
  Future<Watchlist> save(Watchlist watchlist) async {
    try {
      final response = await _dio.put<Map<String, dynamic>>(
        '/api/v1/me/watchlist',
        data: watchlist.toJson(),
      );
      return Watchlist.fromJson(response.data!);
    } on DioException catch (error) {
      throw mapDioError(error);
    }
  }

  @override
  Future<List<Category>> categories() async {
    try {
      final response = await _dio.get<List<dynamic>>('/api/v1/categories');
      return response.data!
          .cast<Map<String, dynamic>>()
          .map((row) => Category(row['slug'] as String, row['label'] as String))
          .toList(growable: false);
    } on DioException catch (error) {
      throw mapDioError(error);
    }
  }
}

final watchlistRepositoryProvider = Provider<WatchlistRepository>(
  (ref) => ApiWatchlistRepository(ref.watch(dioProvider)),
);

final categoriesProvider = FutureProvider<List<Category>>(
  (ref) => ref.watch(watchlistRepositoryProvider).categories(),
);

class WatchlistController extends AsyncNotifier<Watchlist> {
  @override
  Future<Watchlist> build() => ref.watch(watchlistRepositoryProvider).load();

  /// Salvataggio ottimistico: in caso di errore torna allo stato del server.
  Future<void> save(Watchlist next) async {
    final previous = state;
    state = AsyncData(next);
    try {
      final saved = await ref.read(watchlistRepositoryProvider).save(next);
      state = AsyncData(saved);
      ref.invalidate(feedControllerProvider(FeedKind.watchlist));
    } on AppFailure {
      state = previous;
      rethrow;
    }
  }

  Future<void> addTicker(String raw) async {
    final ticker = raw.trim().toUpperCase();
    final current = state.value;
    if (current == null || ticker.isEmpty) return;
    if (current.tickers.contains(ticker)) return;
    await save(
      Watchlist(
        tickers: [...current.tickers, ticker],
        categories: current.categories,
      ),
    );
  }

  Future<void> removeTicker(String ticker) async {
    final current = state.value;
    if (current == null) return;
    await save(
      Watchlist(
        tickers: current.tickers.where((t) => t != ticker).toList(),
        categories: current.categories,
      ),
    );
  }

  Future<void> toggleCategory(String slug) async {
    final current = state.value;
    if (current == null) return;
    final categories = current.categories.contains(slug)
        ? current.categories.where((c) => c != slug).toList()
        : [...current.categories, slug];
    await save(Watchlist(tickers: current.tickers, categories: categories));
  }
}

final watchlistProvider = AsyncNotifierProvider<WatchlistController, Watchlist>(
  WatchlistController.new,
);
