import 'package:flutter/material.dart';

/// Skeleton con la stessa struttura della card: il layout non salta all'arrivo dei dati.
class FeedSkeleton extends StatefulWidget {
  const FeedSkeleton({super.key});

  @override
  State<FeedSkeleton> createState() => _FeedSkeletonState();
}

class _FeedSkeletonState extends State<FeedSkeleton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pulse = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 900),
    lowerBound: 0.45,
  )..repeat(reverse: true);

  @override
  void dispose() {
    _pulse.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final color = Theme.of(context).colorScheme.surfaceContainerHighest;
    return Semantics(
      label: 'Caricamento notizie',
      child: FadeTransition(
        opacity: _pulse,
        child: ListView.separated(
          physics: const NeverScrollableScrollPhysics(),
          itemCount: 8,
          separatorBuilder: (_, _) => const Divider(height: 1),
          itemBuilder: (_, index) => Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _Bar(width: 120, height: 11, color: color),
                const SizedBox(height: 10),
                _Bar(width: double.infinity, height: 16, color: color),
                const SizedBox(height: 7),
                _Bar(width: index.isEven ? 240 : 190, height: 16, color: color),
                const SizedBox(height: 10),
                _Bar(width: double.infinity, height: 12, color: color),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _Bar extends StatelessWidget {
  const _Bar({required this.width, required this.height, required this.color});
  final double width;
  final double height;
  final Color color;

  @override
  Widget build(BuildContext context) => Container(
    width: width,
    height: height,
    decoration: BoxDecoration(
      color: color,
      borderRadius: BorderRadius.circular(4),
    ),
  );
}
