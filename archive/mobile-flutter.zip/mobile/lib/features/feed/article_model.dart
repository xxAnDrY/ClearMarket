import 'package:flutter/foundation.dart';

enum Sentiment {
  positive,
  neutral,
  negative;

  /// Un valore aggiunto in futuro dal server non deve rompere le app gia' installate.
  static Sentiment parse(Object? value) => switch (value) {
    'positive' => Sentiment.positive,
    'negative' => Sentiment.negative,
    _ => Sentiment.neutral,
  };
}

@immutable
class ArticleModel {
  const ArticleModel({
    required this.id,
    required this.title,
    required this.summary,
    required this.sourceName,
    required this.sourceUrl,
    required this.translated,
    required this.publishedAt,
    required this.category,
    required this.relatedTickers,
    required this.sentiment,
  });

  factory ArticleModel.fromJson(Map<String, dynamic> json) {
    final sentiment = json['sentiment'] as Map<String, dynamic>?;
    final source = json['source'] as Map<String, dynamic>;
    return ArticleModel(
      id: json['id'] as String,
      title: json['title'] as String,
      summary: json['summary'] as String? ?? '',
      sourceName: source['name'] as String,
      sourceUrl: json['source_url'] as String,
      translated: json['translated'] as bool? ?? false,
      publishedAt: DateTime.parse(json['published_at'] as String).toLocal(),
      category: json['category'] as String,
      relatedTickers: List<String>.unmodifiable(
        json['related_tickers'] as List<dynamic>? ?? const [],
      ),
      sentiment: Sentiment.parse(sentiment?['label']),
    );
  }

  final String id;
  final String title;
  final String summary;
  final String sourceName;
  /// Link canonico all'articolo originale.
  final String sourceUrl;

  /// Titolo e sommario sono stati tradotti in italiano da una fonte estera.
  final bool translated;
  final DateTime publishedAt;
  final String category;
  final List<String> relatedTickers;
  final Sentiment sentiment;
}

@immutable
class FeedPage {
  const FeedPage({required this.items, this.nextCursor});

  factory FeedPage.fromJson(Map<String, dynamic> json) {
    final info = json['page_info'] as Map<String, dynamic>;
    return FeedPage(
      items: (json['data'] as List<dynamic>)
          .cast<Map<String, dynamic>>()
          .map(ArticleModel.fromJson)
          .toList(growable: false),
      nextCursor: info['has_more'] == true
          ? info['next_cursor'] as String?
          : null,
    );
  }

  final List<ArticleModel> items;
  final String? nextCursor;
}
