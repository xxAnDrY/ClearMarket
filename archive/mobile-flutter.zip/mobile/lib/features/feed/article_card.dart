import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'package:url_launcher/url_launcher.dart';

import '../../core/theme.dart';
import 'article_model.dart';

class ArticleCard extends StatelessWidget {
  const ArticleCard({super.key, required this.article, this.onOpen});

  final ArticleModel article;

  /// Iniettabile nei test; di default apre la fonte originale.
  final ValueChanged<ArticleModel>? onOpen;

  /// Browser in-app; se il telefono non lo supporta, browser predefinito.
  static Future<bool> _launch(Uri uri) async {
    try {
      if (await launchUrl(uri, mode: LaunchMode.inAppBrowserView)) return true;
    } on PlatformException {
      // Nessun provider di Custom Tabs sul dispositivo.
    }
    try {
      return await launchUrl(uri, mode: LaunchMode.externalApplication);
    } on PlatformException {
      return false;
    }
  }

  Future<void> _open(BuildContext context) async {
    if (onOpen != null) return onOpen!(article);
    final messenger = ScaffoldMessenger.of(context);
    final uri = Uri.tryParse(article.sourceUrl);
    final allowed = uri != null && (uri.isScheme('http') || uri.isScheme('https'));
    if (!allowed || !await _launch(uri)) {
      messenger.showSnackBar(
        const SnackBar(content: Text('Impossibile aprire l\'articolo')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final muted = theme.colorScheme.onSurfaceVariant;
    final hasTags =
        article.relatedTickers.isNotEmpty ||
        article.sentiment != Sentiment.neutral;

    return InkWell(
      onTap: () => _open(context),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Flexible(
                  child: Text(
                    article.sourceName.toUpperCase(),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: theme.textTheme.labelSmall?.copyWith(
                      color: theme.colorScheme.primary,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 0.6,
                    ),
                  ),
                ),
                Text(
                  '  ·  ${timeago.format(article.publishedAt, locale: 'it')}'
                  '${article.translated ? '  ·  Tradotto' : ''}',
                  style: theme.textTheme.labelSmall?.copyWith(color: muted),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Text(article.title, style: theme.textTheme.titleMedium),
            if (article.summary.isNotEmpty) ...[
              const SizedBox(height: 4),
              Text(
                article.summary,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: theme.textTheme.bodyMedium?.copyWith(color: muted),
              ),
            ],
            if (hasTags) ...[
              const SizedBox(height: 10),
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: [
                  if (article.sentiment != Sentiment.neutral)
                    SentimentChip(sentiment: article.sentiment),
                  for (final ticker in article.relatedTickers.take(4))
                    TickerTag(ticker: ticker),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class TickerTag extends StatelessWidget {
  const TickerTag({super.key, required this.ticker});
  final String ticker;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return DecoratedBox(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(4),
        color: theme.colorScheme.surfaceContainerHighest,
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
        child: Text(
          ticker,
          style: theme.textTheme.labelSmall?.copyWith(
            fontWeight: FontWeight.w600,
            fontFeatures: const [FontFeature.tabularFigures()],
          ),
        ),
      ),
    );
  }
}

class SentimentChip extends StatelessWidget {
  const SentimentChip({super.key, required this.sentiment});
  final Sentiment sentiment;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colors = theme.extension<MarketColors>()!;
    // Testo e icona oltre al colore: il daltonismo rosso/verde e' comune.
    final (label, icon, color) = switch (sentiment) {
      Sentiment.positive => ('Positivo', Icons.arrow_upward, colors.positive),
      Sentiment.negative => ('Negativo', Icons.arrow_downward, colors.negative),
      Sentiment.neutral => ('Neutro', Icons.remove, colors.neutral),
    };
    return DecoratedBox(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(4),
        color: color.withValues(alpha: 0.14),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 12, color: color),
            const SizedBox(width: 3),
            Text(
              label,
              style: theme.textTheme.labelSmall?.copyWith(
                color: color,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
