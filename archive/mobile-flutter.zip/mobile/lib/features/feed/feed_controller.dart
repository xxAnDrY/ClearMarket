import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/failures.dart';
import 'article_model.dart';
import 'feed_repository.dart';

/// `AsyncValue` copre il primo caricamento; da li' in poi la lista resta a schermo
/// e gli stati di paginazione vivono qui.
@immutable
class FeedState {
  const FeedState({
    required this.items,
    this.nextCursor,
    this.isLoadingMore = false,
    this.loadMoreError,
  });

  final List<ArticleModel> items;
  final String? nextCursor;
  final bool isLoadingMore;
  final AppFailure? loadMoreError;

  bool get hasMore => nextCursor != null;

  FeedState copyWith({
    List<ArticleModel>? items,
    String? Function()? nextCursor,
    bool? isLoadingMore,
    AppFailure? Function()? loadMoreError,
  }) => FeedState(
    items: items ?? this.items,
    nextCursor: nextCursor != null ? nextCursor() : this.nextCursor,
    isLoadingMore: isLoadingMore ?? this.isLoadingMore,
    loadMoreError: loadMoreError != null ? loadMoreError() : this.loadMoreError,
  );
}

class FeedController extends AsyncNotifier<FeedState> {
  FeedController(this.kind);
  final FeedKind kind;

  /// Incrementato da ogni refresh: una pagina partita prima del refresh viene
  /// ignorata, altrimenti si accoderebbe a una lista gia' sostituita.
  int _generation = 0;

  FeedRepository get _repository => ref.read(feedRepositoryProvider);

  static FeedState _fromPage(FeedPage page) =>
      FeedState(items: page.items, nextCursor: page.nextCursor);

  @override
  Future<FeedState> build() async {
    _generation++;
    return _fromPage(await ref.watch(feedRepositoryProvider).fetch(kind));
  }

  /// Pull-to-refresh. Se fallisce la lista resta com'e' e l'errore sale alla UI.
  Future<void> refresh() async {
    final generation = ++_generation;
    final page = await _repository.fetch(kind);
    if (generation == _generation) state = AsyncData(_fromPage(page));
  }

  Future<void> loadMore() async {
    final current = state.value;
    if (current == null ||
        current.isLoadingMore ||
        !current.hasMore ||
        current.loadMoreError != null) {
      return;
    }
    await _fetchNext(current);
  }

  /// Ripresa esplicita dal footer: `loadMore` si ferma dopo un errore, per non
  /// ritentare in loop a ogni evento di scroll.
  Future<void> retryLoadMore() async {
    final current = state.value;
    if (current == null || current.isLoadingMore || !current.hasMore) return;
    await _fetchNext(current);
  }

  Future<void> _fetchNext(FeedState current) async {
    final generation = _generation;
    state = AsyncData(
      current.copyWith(isLoadingMore: true, loadMoreError: () => null),
    );
    try {
      final page = await _repository.fetch(kind, cursor: current.nextCursor);
      if (generation != _generation) return;
      final known = current.items.map((item) => item.id).toSet();
      state = AsyncData(
        FeedState(
          items: [
            ...current.items,
            ...page.items.where((item) => !known.contains(item.id)),
          ],
          nextCursor: page.nextCursor,
        ),
      );
    } on AppFailure catch (failure) {
      if (generation != _generation) return;
      state = AsyncData(
        current.copyWith(isLoadingMore: false, loadMoreError: () => failure),
      );
    }
  }
}

final feedControllerProvider =
    AsyncNotifierProvider.family<FeedController, FeedState, FeedKind>(
      FeedController.new,
    );
