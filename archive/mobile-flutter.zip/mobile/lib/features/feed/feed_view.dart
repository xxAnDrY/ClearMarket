import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/failures.dart';
import 'article_card.dart';
import 'feed_controller.dart';
import 'feed_repository.dart';
import 'feed_skeleton.dart';

/// Lista riutilizzata da Top News e Watchlist.
/// Stati: skeleton -> dati | errore a pagina piena | vuoto; piu' i footer di paginazione.
class FeedView extends ConsumerStatefulWidget {
  const FeedView({super.key, required this.kind, this.emptyState});

  final FeedKind kind;
  final Widget? emptyState;

  @override
  ConsumerState<FeedView> createState() => _FeedViewState();
}

class _FeedViewState extends ConsumerState<FeedView> {
  /// Anticipo rispetto al fondo: la pagina arriva prima che l'utente la raggiunga.
  static const _prefetchPixels = 600.0;

  bool _onScroll(ScrollNotification notification) {
    if (notification.metrics.extentAfter < _prefetchPixels) {
      ref.read(feedControllerProvider(widget.kind).notifier).loadMore();
    }
    return false;
  }

  Future<void> _refresh() async {
    final messenger = ScaffoldMessenger.of(context);
    try {
      await ref.read(feedControllerProvider(widget.kind).notifier).refresh();
    } on AppFailure catch (failure) {
      messenger.showSnackBar(SnackBar(content: Text(failure.message)));
    }
  }

  @override
  Widget build(BuildContext context) {
    final provider = feedControllerProvider(widget.kind);
    final feed = ref.watch(provider);

    // `value` resta valorizzato durante un rebuild: niente skeleton se c'e' gia' una lista.
    final data = feed.value;
    if (data == null) {
      if (feed.hasError) {
        return ErrorRetry(
          message: _messageOf(feed.error),
          onRetry: () => ref.invalidate(provider),
        );
      }
      return const FeedSkeleton();
    }

    if (data.items.isEmpty) {
      return RefreshIndicator(
        onRefresh: _refresh,
        child: LayoutBuilder(
          builder: (context, constraints) => SingleChildScrollView(
            physics: const AlwaysScrollableScrollPhysics(),
            child: ConstrainedBox(
              constraints: BoxConstraints(minHeight: constraints.maxHeight),
              child: Center(
                child: widget.emptyState ?? const Text('Nessuna notizia'),
              ),
            ),
          ),
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _refresh,
      child: NotificationListener<ScrollNotification>(
        onNotification: _onScroll,
        child: ListView.separated(
          // Conserva la posizione tra i tab e dopo il ritorno all'app.
          key: PageStorageKey(widget.kind),
          physics: const AlwaysScrollableScrollPhysics(),
          itemCount: data.items.length + 1,
          separatorBuilder: (_, _) => const Divider(height: 1),
          itemBuilder: (context, index) {
            if (index < data.items.length) {
              return ArticleCard(article: data.items[index]);
            }
            return _PaginationFooter(
              state: data,
              onRetry: () => ref.read(provider.notifier).retryLoadMore(),
            );
          },
        ),
      ),
    );
  }
}

String _messageOf(Object? error) =>
    error is AppFailure ? error.message : const ServerFailure().message;

class _PaginationFooter extends StatelessWidget {
  const _PaginationFooter({required this.state, required this.onRetry});

  final FeedState state;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    final muted = Theme.of(context).colorScheme.onSurfaceVariant;
    final child = switch (state) {
      FeedState(loadMoreError: final AppFailure error) => TextButton.icon(
        onPressed: onRetry,
        icon: const Icon(Icons.refresh),
        label: Text(error.message),
      ),
      FeedState(hasMore: true) => const SizedBox.square(
        dimension: 24,
        child: CircularProgressIndicator(strokeWidth: 2.5),
      ),
      _ => Text('Sei aggiornato', style: TextStyle(color: muted)),
    };
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 20),
      child: Center(child: child),
    );
  }
}

class ErrorRetry extends StatelessWidget {
  const ErrorRetry({super.key, required this.message, required this.onRetry});

  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) => Center(
    child: Padding(
      padding: const EdgeInsets.all(32),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.cloud_off_outlined, size: 40),
          const SizedBox(height: 12),
          Text(message, textAlign: TextAlign.center),
          const SizedBox(height: 12),
          FilledButton.tonal(onPressed: onRetry, child: const Text('Riprova')),
        ],
      ),
    ),
  );
}
