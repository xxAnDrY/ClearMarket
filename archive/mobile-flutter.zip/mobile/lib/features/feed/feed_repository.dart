import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/api_client.dart';
import '../../core/failures.dart';
import 'article_model.dart';

enum FeedKind { top, watchlist }

abstract interface class FeedRepository {
  Future<FeedPage> fetch(FeedKind kind, {String? cursor});
}

class ApiFeedRepository implements FeedRepository {
  const ApiFeedRepository(this._dio);
  final Dio _dio;

  static const _pageSize = 20;

  @override
  Future<FeedPage> fetch(FeedKind kind, {String? cursor}) async {
    final (path, scope) = switch (kind) {
      FeedKind.top => ('/api/v1/feed', <String, Object>{'scope': 'top'}),
      FeedKind.watchlist => ('/api/v1/feed/watchlist', const <String, Object>{}),
    };
    try {
      final response = await _dio.get<Map<String, dynamic>>(
        path,
        queryParameters: {
          ...scope,
          'limit': _pageSize,
          'cursor': ?cursor,
        },
      );
      return FeedPage.fromJson(response.data!);
    } on DioException catch (error) {
      throw mapDioError(error);
    }
  }
}

final feedRepositoryProvider = Provider<FeedRepository>(
  (ref) => ApiFeedRepository(ref.watch(dioProvider)),
);
