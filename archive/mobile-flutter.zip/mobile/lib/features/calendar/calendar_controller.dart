import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_timezone/flutter_timezone.dart';

import '../../core/api_client.dart';
import '../../core/failures.dart';

enum EventImpact {
  low,
  medium,
  high,
  holiday;

  static EventImpact parse(Object? value) => EventImpact.values.firstWhere(
    (impact) => impact.name == value,
    orElse: () => EventImpact.low,
  );
}

@immutable
class EconomicEvent {
  const EconomicEvent({
    required this.id,
    required this.title,
    required this.country,
    required this.startsAt,
    required this.impact,
    this.forecast,
    this.previous,
    this.actual,
  });

  factory EconomicEvent.fromJson(Map<String, dynamic> json) => EconomicEvent(
    id: json['id'] as String,
    title: json['title'] as String,
    country: json['country'] as String,
    startsAt: DateTime.parse(json['starts_at'] as String).toLocal(),
    impact: EventImpact.parse(json['impact']),
    forecast: json['forecast'] as String?,
    previous: json['previous'] as String?,
    actual: json['actual'] as String?,
  );

  final String id;
  final String title;
  final String country;
  final DateTime startsAt;
  final EventImpact impact;
  final String? forecast;
  final String? previous;
  final String? actual;
}

abstract interface class CalendarRepository {
  Future<List<EconomicEvent>> eventsOn(DateTime day);
}

class ApiCalendarRepository implements CalendarRepository {
  const ApiCalendarRepository(this._dio);
  final Dio _dio;

  @override
  Future<List<EconomicEvent>> eventsOn(DateTime day) async {
    final timezone = await FlutterTimezone.getLocalTimezone();
    final date =
        '${day.year}-${day.month.toString().padLeft(2, '0')}-'
        '${day.day.toString().padLeft(2, '0')}';
    try {
      final response = await _dio.get<Map<String, dynamic>>(
        '/api/v1/calendar',
        queryParameters: {'date': date, 'tz': timezone.identifier},
      );
      return (response.data!['data'] as List<dynamic>)
          .cast<Map<String, dynamic>>()
          .map(EconomicEvent.fromJson)
          .toList(growable: false);
    } on DioException catch (error) {
      throw mapDioError(error);
    }
  }
}

final calendarRepositoryProvider = Provider<CalendarRepository>(
  (ref) => ApiCalendarRepository(ref.watch(dioProvider)),
);

/// Giorno selezionato, a mezzanotte locale.
class SelectedDay extends Notifier<DateTime> {
  @override
  DateTime build() {
    final now = DateTime.now();
    return DateTime(now.year, now.month, now.day);
  }

  void shift(int days) =>
      state = DateTime(state.year, state.month, state.day + days);
}

final selectedDayProvider = NotifierProvider<SelectedDay, DateTime>(
  SelectedDay.new,
);

final calendarEventsProvider =
    FutureProvider.family<List<EconomicEvent>, DateTime>(
      (ref, day) => ref.watch(calendarRepositoryProvider).eventsOn(day),
    );
