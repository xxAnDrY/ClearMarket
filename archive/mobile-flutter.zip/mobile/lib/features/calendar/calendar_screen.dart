import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../core/failures.dart';
import '../../core/theme.dart';
import '../feed/feed_view.dart';
import 'calendar_controller.dart';

class CalendarScreen extends ConsumerWidget {
  const CalendarScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final day = ref.watch(selectedDayProvider);
    final events = ref.watch(calendarEventsProvider(day));
    final selector = ref.read(selectedDayProvider.notifier);

    return Scaffold(
      appBar: AppBar(title: const Text('Calendario economico')),
      body: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              IconButton(
                tooltip: 'Giorno precedente',
                icon: const Icon(Icons.chevron_left),
                onPressed: () => selector.shift(-1),
              ),
              Text(
                toBeginningOfSentenceCase(
                  DateFormat('EEEE d MMMM', 'it').format(day),
                ),
                style: Theme.of(context).textTheme.titleSmall,
              ),
              IconButton(
                tooltip: 'Giorno successivo',
                icon: const Icon(Icons.chevron_right),
                onPressed: () => selector.shift(1),
              ),
            ],
          ),
          const Divider(height: 1),
          Expanded(
            child: events.when(
              skipLoadingOnRefresh: true,
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (error, _) => ErrorRetry(
                message: error is AppFailure
                    ? error.message
                    : const ServerFailure().message,
                onRetry: () => ref.invalidate(calendarEventsProvider(day)),
              ),
              data: (items) => RefreshIndicator(
                onRefresh: () =>
                    ref.refresh(calendarEventsProvider(day).future),
                child: items.isEmpty
                    ? ListView(
                        children: const [
                          SizedBox(height: 120),
                          Center(child: Text('Nessun evento per questo giorno')),
                        ],
                      )
                    : ListView.separated(
                        itemCount: items.length,
                        separatorBuilder: (_, _) => const Divider(height: 1),
                        itemBuilder: (_, index) =>
                            EventTile(event: items[index]),
                      ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class EventTile extends StatelessWidget {
  const EventTile({super.key, required this.event});
  final EconomicEvent event;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colors = theme.extension<MarketColors>()!;
    final muted = theme.colorScheme.onSurfaceVariant;
    final (impactColor, impactLabel) = switch (event.impact) {
      EventImpact.high => (colors.negative, 'Impatto alto'),
      EventImpact.medium => (theme.colorScheme.primary, 'Impatto medio'),
      EventImpact.low => (colors.neutral, 'Impatto basso'),
      EventImpact.holiday => (colors.neutral, 'Festivita'),
    };
    final figures = [
      if (event.actual != null) 'Eff. ${event.actual}',
      if (event.forecast != null) 'Prev. ${event.forecast}',
      if (event.previous != null) 'Prec. ${event.previous}',
    ].join('   ');

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 52,
            child: Text(
              DateFormat.Hm('it').format(event.startsAt),
              style: theme.textTheme.bodyMedium?.copyWith(
                fontWeight: FontWeight.w600,
                fontFeatures: const [FontFeature.tabularFigures()],
              ),
            ),
          ),
          Tooltip(
            message: impactLabel,
            child: Padding(
              padding: const EdgeInsets.only(top: 6, right: 10),
              child: Icon(Icons.circle, size: 9, color: impactColor),
            ),
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${event.country}  ${event.title}',
                  style: theme.textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                if (figures.isNotEmpty) ...[
                  const SizedBox(height: 3),
                  Text(
                    figures,
                    style: theme.textTheme.labelSmall?.copyWith(color: muted),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}
