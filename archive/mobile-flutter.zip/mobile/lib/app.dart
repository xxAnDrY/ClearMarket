import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'core/theme.dart';
import 'features/calendar/calendar_screen.dart';
import 'features/feed/feed_repository.dart';
import 'features/feed/feed_view.dart';
import 'features/watchlist/watchlist_screen.dart';

class ClearMarketApp extends StatelessWidget {
  const ClearMarketApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'ClearMarket',
    debugShowCheckedModeBanner: false,
    theme: lightTheme,
    darkTheme: darkTheme,
    themeMode: ThemeMode.system,
    locale: const Locale('it'),
    supportedLocales: const [Locale('it')],
    localizationsDelegates: GlobalMaterialLocalizations.delegates,
    home: const HomeShell(),
  );
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _tab = 0;

  @override
  Widget build(BuildContext context) => Scaffold(
    // IndexedStack mantiene scroll e stato di ogni tab.
    body: IndexedStack(
      index: _tab,
      children: const [
        _TopNewsScreen(),
        WatchlistScreen(),
        CalendarScreen(),
      ],
    ),
    bottomNavigationBar: NavigationBar(
      selectedIndex: _tab,
      onDestinationSelected: (tab) => setState(() => _tab = tab),
      destinations: const [
        NavigationDestination(icon: Icon(Icons.bolt), label: 'Top News'),
        NavigationDestination(icon: Icon(Icons.star_outline), label: 'Watchlist'),
        NavigationDestination(
          icon: Icon(Icons.event_outlined),
          label: 'Calendario',
        ),
      ],
    ),
  );
}

class _TopNewsScreen extends StatelessWidget {
  const _TopNewsScreen();

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('ClearMarket')),
    body: const FeedView(kind: FeedKind.top),
  );
}
